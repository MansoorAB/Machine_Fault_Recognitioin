from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Machine Fault Detection model package",
    author="Mansoor Baig",
    packages=find_packages(),
    license="MIT"
)

